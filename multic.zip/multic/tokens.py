from itsdangerous import URLSafeSerializer, BadSignature
from flask import current_app

# Token payload format:
# {"t": "<type>", "id": <int>}
# Types: "project", "episode", "frame"

def _serializer() -> URLSafeSerializer:
    secret = current_app.secret_key
    if not secret:
        raise RuntimeError("SECRET_KEY is not configured.")
    return URLSafeSerializer(secret_key=secret, salt="minion-pbd-tokens-v1")

def make_token(obj_type: str, obj_id: int) -> str:
    s = _serializer()
    return s.dumps({"t": obj_type, "id": int(obj_id)})

def parse_token(token: str, expected_type: str) -> int:
    s = _serializer()
    try:
        payload = s.loads(token)
    except BadSignature as e:
        raise ValueError("bad_token") from e

    if not isinstance(payload, dict) or payload.get("t") != expected_type:
        raise ValueError("bad_token_type")
    return int(payload["id"])
