from flask import Blueprint, render_template, request, redirect, url_for, flash
from db import get_conn
from tokens import make_token, parse_token
from routes.role_rules import validate_stage_responsible, allowed_specializations, normalize_value

bp = Blueprint("frame", __name__, url_prefix="/frames")

def ensure_frame_stages(id_frame: int, planned_end_date=None) -> bool:
    """Создаёт этапы (Stage) для кадра, если их нет. Возвращает True, если этапы добавлены."""
    cnt = fetch_one('SELECT COUNT(*)::int AS c FROM "Stage" WHERE "id_frame"=%(fid)s;', {"fid": id_frame})
    if cnt and cnt.get("c", 0) > 0:
        return False

    # 1) попытка вызвать процедуру БД (если существует)
    try:
        execute('CALL "sp_create_default_stages_for_frame"(%(fid)s);', {"fid": id_frame})
        return True
    except Exception:
        pass

    # 2) фолбэк: создаём этапы через INSERT..SELECT
    emp = fetch_one('''
        SELECT "id_employee"
        FROM "Employees"
        WHERE COALESCE("is_active", FALSE) = TRUE
        ORDER BY "id_employee"
        LIMIT 1;
    ''')
    if not emp:
        emp = fetch_one('SELECT "id_employee" FROM "Employees" ORDER BY "id_employee" LIMIT 1;')
    if not emp:
        return False

    st = fetch_one('''
        SELECT "id_stage_status"
        FROM "StageStatus"
        WHERE "stage_status_name" = 'Не начат'
        LIMIT 1;
    ''')
    if not st:
        st = fetch_one('SELECT "id_stage_status" FROM "StageStatus" ORDER BY "id_stage_status" LIMIT 1;')
    if not st:
        return False

    execute('''WITH st_src AS (
    SELECT stt."stage_type_id", stt."execution_order"
    FROM "StageType" stt
    WHERE LOWER(COALESCE(stt."stage_level", '')) = 'frame'
),
st_src2 AS (
    SELECT stt."stage_type_id", stt."execution_order"
    FROM "StageType" stt
    WHERE LOWER(COALESCE(stt."stage_level", '')) = 'episode'
)
INSERT INTO "Stage"
("id_project","id_episode","id_frame",
 "id_responsible_employee","stage_type_id","id_stage_status",
 "start_datetime","actual_end_datetime","planned_end_date")
SELECT
  NULL, NULL, %(fid)s,
  %(emp)s, x."stage_type_id", %(sid)s,
  NULL, NULL, %(planned)s
FROM (
  SELECT * FROM st_src
  UNION ALL
  SELECT * FROM st_src2
  WHERE NOT EXISTS (SELECT 1 FROM st_src)
) x
ORDER BY x."execution_order" NULLS LAST, x."stage_type_id";''', {"fid": id_frame, "emp": emp["id_employee"], "sid": st["id_stage_status"], "planned": planned_end_date})

    return True


def fetch_all(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchall()

def fetch_one(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchone()

def execute(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})

@bp.get("/<frame_token>")
def view_frame(frame_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
    except ValueError:
        flash("Неверная ссылка на кадр.", "error")
        return redirect(url_for("project.list_projects"))

    fr = fetch_one('''
        SELECT 
            f.*,
            e."episode_name",
            e."episode_number_in_project",
            p."project_name",
            e."id_episode",
            p."id_project"
        FROM "Frame" f
        JOIN "Episode" e ON e."id_episode" = f."id_episode"
        JOIN "Project" p ON p."id_project" = e."id_project"
        WHERE f."id_frame" = %(fid)s;
    ''', {"fid": id_frame})

    if not fr:
        flash("Кадр не найден.", "error")
        return redirect(url_for("project.list_projects"))

    project_token = make_token("project", fr["id_project"])
    episode_token = make_token("episode", fr["id_episode"])

    # stages for this frame (to demonstrate procedures/functions/triggers from DB)
    stages = fetch_all('''
        SELECT
            s."id_stage",
            s."id_responsible_employee",
            st."stage_type_name",
            COALESCE(ss."stage_status_name", '—') AS stage_status_name,
            s."planned_end_date",
            s."start_datetime",
            s."actual_end_datetime",
            COALESCE((emp."surname" || ' ' || emp."name"), '—') AS responsible,
            (
              SELECT dp."progress_percent"
              FROM "DailyProgress" dp
              WHERE dp."id_stage" = s."id_stage"
              ORDER BY dp."progress_date" DESC, dp."id_progress" DESC
              LIMIT 1
            ) AS last_progress_percent
        FROM "Stage" s
        JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
        LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        LEFT JOIN "Employees" emp ON emp."id_employee" = s."id_responsible_employee"
        WHERE s."id_frame" = %(fid)s
        ORDER BY st."execution_order", s."id_stage";
    ''', {"fid": id_frame})

    # Если этапов у кадра нет (например, кадр был создан до внедрения автосоздания) — создаём их автоматически
    if not stages:
        created = ensure_frame_stages(id_frame, fr.get("planned_due_date"))
        if created:
            stages = fetch_all('''
                SELECT
                    s."id_stage",
                    s."id_responsible_employee",
                    st."stage_type_name",
                    COALESCE(ss."stage_status_name", '—') AS stage_status_name,
                    s."planned_end_date",
                    s."start_datetime",
                    s."actual_end_datetime",
                    COALESCE((emp."surname" || ' ' || emp."name"), '—') AS responsible,
                    (
                      SELECT dp."progress_percent"
                      FROM "DailyProgress" dp
                      WHERE dp."id_stage" = s."id_stage"
                      ORDER BY dp."progress_date" DESC, dp."id_progress" DESC
                      LIMIT 1
                    ) AS last_progress_percent
                FROM "Stage" s
                JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
                LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
                LEFT JOIN "Employees" emp ON emp."id_employee" = s."id_responsible_employee"
                WHERE s."id_frame" = %(fid)s
                ORDER BY st."execution_order", s."id_stage";
            ''', {"fid": id_frame})


    for s in stages:
        s["token"] = make_token("stage", s["id_stage"])

    stage_statuses = fetch_all('SELECT "id_stage_status","stage_status_name" FROM "StageStatus" ORDER BY "id_stage_status";')
    check_results = fetch_all('SELECT "id_check_result","check_result_name" FROM "CheckResult" ORDER BY "id_check_result";')
    try:
        checkers = fetch_all('''
            SELECT
                e."id_employee",
                (e."surname" || ' ' || e."name") AS fio,
                sp."specialization_name" AS specialization
            FROM "Employees" e
            LEFT JOIN "Spesialization" sp
                   ON sp."id_spesialization" = e."id_spesialization"
            WHERE COALESCE(e."is_active", TRUE) = TRUE
            ORDER BY e."surname","name";
        ''')
    except Exception:
        checkers = fetch_all('''
            SELECT
                e."id_employee",
                (e."surname" || ' ' || e."name") AS fio,
                NULL AS specialization
            FROM "Employees" e
            WHERE COALESCE(e."is_active", TRUE) = TRUE
            ORDER BY e."surname","name";
        ''')

    employees_by_stage = {}
    for s in stages:
        allowed = allowed_specializations(s.get("stage_type_name"))
        if allowed:
            employees_by_stage[s["id_stage"]] = [
                e for e in checkers if normalize_value(e.get("specialization")) in allowed
            ]
        else:
            employees_by_stage[s["id_stage"]] = checkers

    return render_template(
        "frames_view.html",
        fr=fr,
        frame_token=frame_token,
        project_token=project_token,
        episode_token=episode_token,
        stages=stages,
        stage_statuses=stage_statuses,
        check_results=check_results,
        checkers=checkers,
        employees_by_stage=employees_by_stage,
        employees=checkers
    )

@bp.get("/new/<episode_token>")
def new_frame_form(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    ep = fetch_one('''
        SELECT e."id_episode", e."episode_name", e."episode_number_in_project",
               p."id_project", p."project_name"
        FROM "Episode" e
        JOIN "Project" p ON p."id_project" = e."id_project"
        WHERE e."id_episode"=%(eid)s;
    ''', {"eid": id_episode})

    if not ep:
        flash("Эпизод не найден.", "error")
        return redirect(url_for("project.list_projects"))

    return render_template("frames_form.html", mode="new", ep=ep, episode_token=episode_token, fr=None, frame_token=None)

@bp.post("/new/<episode_token>")
def create_frame(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    data = {
        "id_episode": id_episode,
        "frame_number_in_episode": request.form.get("frame_number_in_episode") or None,
        "planned_due_date": request.form.get("planned_due_date") or None,
        "actual_done_date": request.form.get("actual_done_date") or None,
    }

    if not data["frame_number_in_episode"]:
        flash("Поле «Номер кадра в эпизоде» обязательно.", "error")
        return redirect(url_for("frame.new_frame_form", episode_token=episode_token))

    row = fetch_one('''
        INSERT INTO "Frame"
        ("id_episode","frame_number_in_episode","planned_due_date","actual_done_date")
        VALUES
        (%(id_episode)s,%(frame_number_in_episode)s,%(planned_due_date)s,%(actual_done_date)s)
        RETURNING "id_frame";
    ''', data)

    fid = row.get("id_frame") if row else None


    if fid:
        ensure_frame_stages(fid, data.get("planned_due_date"))
    # Автосоздание этапов кадра (Stage), чтобы таблица Stage не была пустой
    if fid:
        cnt = fetch_one('SELECT COUNT(*)::int AS c FROM "Stage" WHERE "id_frame"=%(fid)s;', {"fid": fid})
        if cnt and cnt.get("c", 0) == 0:
            created = False

            # 1) попытка вызвать процедуру БД (если она существует)
            try:
                execute('CALL "sp_create_default_stages_for_frame"(%(fid)s);', {"fid": fid})
                created = True
            except Exception:
                created = False

            # 2) фолбэк: создаём этапы через INSERT..SELECT
            if not created:
                try:
                    emp = fetch_one('''
                        SELECT "id_employee"
                        FROM "Employees"
                        WHERE COALESCE("is_active", FALSE) = TRUE
                        ORDER BY "id_employee"
                        LIMIT 1;
                    ''')
                    if not emp:
                        emp = fetch_one('SELECT "id_employee" FROM "Employees" ORDER BY "id_employee" LIMIT 1;')

                    if not emp:
                        flash("Кадр создан, но этапы не добавлены: таблица Employees пуста.", "error")
                        return redirect(url_for("episode.view_episode", episode_token=episode_token))

                    st = fetch_one('''
                        SELECT "id_stage_status"
                        FROM "StageStatus"
                        WHERE "stage_status_name" = 'Не начат'
                        LIMIT 1;
                    ''')
                    if not st:
                        st = fetch_one('SELECT "id_stage_status" FROM "StageStatus" ORDER BY "id_stage_status" LIMIT 1;')

                    if not st:
                        flash("Кадр создан, но этапы не добавлены: таблица StageStatus пуста.", "error")
                        return redirect(url_for("episode.view_episode", episode_token=episode_token))

                    execute('''
                        WITH st_src AS (
                            SELECT stt."stage_type_id", stt."execution_order"
                            FROM "StageType" stt
                            WHERE LOWER(COALESCE(stt."stage_level", '')) = 'frame'
                        ),
                        st_src2 AS (
                            SELECT stt."stage_type_id", stt."execution_order"
                            FROM "StageType" stt
                            WHERE LOWER(COALESCE(stt."stage_level", '')) = 'episode'
                        )
                        INSERT INTO "Stage"
                        ("id_project","id_episode","id_frame",
                         "id_responsible_employee","stage_type_id","id_stage_status",
                         "start_datetime","actual_end_datetime","planned_end_date")
                        SELECT
                          NULL, NULL, %(fid)s,
                          %(emp)s, x."stage_type_id", %(sid)s,
                          NULL, NULL, %(planned)s
                        FROM (
                          SELECT * FROM st_src
                          UNION ALL
                          SELECT * FROM st_src2
                          WHERE NOT EXISTS (SELECT 1 FROM st_src)
                        ) x
                        ORDER BY x."execution_order" NULLS LAST, x."stage_type_id";
                    ''', {"fid": fid, "emp": emp["id_employee"], "sid": st["id_stage_status"], "planned": data["planned_due_date"]})

                    created = True
                except Exception as e:
                    flash(f"Кадр создан, но этапы не добавлены: {e}", "error")

            if created:
                flash("Кадр добавлен, этапы созданы автоматически.", "ok")
            else:
                flash("Кадр добавлен, но этапы не создались (проверь StageType/StageStatus/Employees).", "error")
        else:
            flash("Кадр добавлен.", "ok")
    else:
        flash("Кадр добавлен.", "ok")

    return redirect(url_for("episode.view_episode", episode_token=episode_token))
@bp.get("/<frame_token>/edit")
def edit_frame_form(frame_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
    except ValueError:
        flash("Неверная ссылка на кадр.", "error")
        return redirect(url_for("project.list_projects"))

    fr = fetch_one('SELECT * FROM "Frame" WHERE "id_frame"=%(fid)s;', {"fid": id_frame})
    if not fr:
        flash("Кадр не найден.", "error")
        return redirect(url_for("project.list_projects"))

    episode_token = make_token("episode", fr["id_episode"])
    ep = fetch_one('''
        SELECT e."id_episode", e."episode_name", e."episode_number_in_project",
               p."id_project", p."project_name"
        FROM "Episode" e
        JOIN "Project" p ON p."id_project" = e."id_project"
        WHERE e."id_episode"=%(eid)s;
    ''', {"eid": fr["id_episode"]})

    return render_template("frames_form.html", mode="edit", ep=ep, episode_token=episode_token, fr=fr, frame_token=frame_token)

@bp.post("/<frame_token>/edit")
def update_frame(frame_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
    except ValueError:
        flash("Неверная ссылка на кадр.", "error")
        return redirect(url_for("project.list_projects"))

    current = fetch_one('SELECT "id_episode" FROM "Frame" WHERE "id_frame"=%(fid)s;', {"fid": id_frame})
    if not current:
        flash("Кадр не найден.", "error")
        return redirect(url_for("project.list_projects"))

    episode_token = make_token("episode", current["id_episode"])

    data = {
        "id_frame": id_frame,
        "frame_number_in_episode": request.form.get("frame_number_in_episode") or None,
        "planned_due_date": request.form.get("planned_due_date") or None,
        "actual_done_date": request.form.get("actual_done_date") or None,
    }

    if not data["frame_number_in_episode"]:
        flash("Поле «Номер кадра в эпизоде» обязательно.", "error")
        return redirect(url_for("frame.edit_frame_form", frame_token=frame_token))

    execute('''
        UPDATE "Frame"
        SET "frame_number_in_episode"=%(frame_number_in_episode)s,
            "planned_due_date"=%(planned_due_date)s,
            "actual_done_date"=%(actual_done_date)s
        WHERE "id_frame"=%(id_frame)s;
    ''', data)

    flash("Кадр обновлён.", "ok")
    return redirect(url_for("frame.view_frame", frame_token=frame_token))

@bp.post("/<frame_token>/delete")
def delete_frame(frame_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
    except ValueError:
        flash("Неверная ссылка на кадр.", "error")
        return redirect(url_for("project.list_projects"))

    fr = fetch_one('SELECT "id_episode" FROM "Frame" WHERE "id_frame"=%(fid)s;', {"fid": id_frame})
    if not fr:
        flash("Кадр не найден.", "error")
        return redirect(url_for("project.list_projects"))

    episode_token = make_token("episode", fr["id_episode"])
    execute('''
        DELETE FROM "StageCheck"
        WHERE "id_stage" IN (
            SELECT s."id_stage"
            FROM "Stage" s
            WHERE s."id_frame" = %(fid)s
        );
    ''', {"fid": id_frame})
    execute('''
        DELETE FROM "DailyProgress"
        WHERE "id_stage" IN (
            SELECT s."id_stage"
            FROM "Stage" s
            WHERE s."id_frame" = %(fid)s
        );
    ''', {"fid": id_frame})
    execute('DELETE FROM "Stage" WHERE "id_frame"=%(fid)s;', {"fid": id_frame})
    execute('DELETE FROM "Frame" WHERE "id_frame"=%(fid)s;', {"fid": id_frame})
    flash("Кадр удалён.", "ok")
    return redirect(url_for("episode.view_episode", episode_token=episode_token))


@bp.post("/<frame_token>/stages/<stage_token>/status")
def update_stage_status(frame_token: str, stage_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка.", "error")
        return redirect(url_for("project.list_projects"))

    id_stage_status = request.form.get("id_stage_status")
    if not id_stage_status:
        flash("Не выбран статус.", "error")
        return redirect(url_for("frame.view_frame", frame_token=frame_token))

    try:
        execute('''
            UPDATE "Stage"
            SET "id_stage_status" = %(sid)s
            WHERE "id_stage" = %(id_stage)s AND "id_frame" = %(id_frame)s;
        ''', {"sid": id_stage_status, "id_stage": id_stage, "id_frame": id_frame})

        ss = fetch_one('''
            SELECT "stage_status_name"
            FROM "StageStatus"
            WHERE "id_stage_status" = %(sid)s;
        ''', {"sid": id_stage_status})
        name = ss["stage_status_name"] if ss else None
        if name:
            n = name.lower()
            if "не нач" in n:
                pct = 0
            elif "в работ" in n:
                pct = 50
            elif "требует" in n or "доработ" in n:
                pct = 70
            elif "заверш" in n or "готов" in n:
                pct = 100
            else:
                pct = 0
        else:
            pct = 0

        execute('''
            INSERT INTO "DailyProgress" ("id_employee","id_stage","progress_date","progress_percent")
            VALUES (
                (SELECT "id_responsible_employee" FROM "Stage" WHERE "id_stage"=%(st)s),
                %(st)s,
                CURRENT_DATE,
                %(pct)s
            );
        ''', {"st": id_stage, "pct": pct})

        flash(f"Статус этапа обновлён, прогресс: {pct}%.", "ok")
    except Exception as e:
        flash(f"Ошибка при обновлении статуса: {e}", "error")

    return redirect(url_for("frame.view_frame", frame_token=frame_token))


@bp.post("/<frame_token>/stages/<stage_token>/responsible")
def update_stage_responsible(frame_token: str, stage_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка.", "error")
        return redirect(url_for("project.list_projects"))

    employee_id = request.form.get("id_responsible_employee") or None
    if employee_id:
        ok, error = validate_stage_responsible(id_stage, int(employee_id))
        if not ok:
            flash(error, "error")
            return redirect(url_for("frame.view_frame", frame_token=frame_token))
    execute('''
        UPDATE "Stage"
        SET "id_responsible_employee" = %(eid)s
        WHERE "id_stage" = %(id_stage)s AND "id_frame" = %(id_frame)s;
    ''', {"eid": employee_id, "id_stage": id_stage, "id_frame": id_frame})

    flash("Ответственный назначен.", "ok")
    return redirect(url_for("frame.view_frame", frame_token=frame_token))


@bp.post("/<frame_token>/stages/<stage_token>/check")
def add_stage_check(frame_token: str, stage_token: str):
    try:
        id_frame = parse_token(frame_token, "frame")
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка.", "error")
        return redirect(url_for("project.list_projects"))

    checker = request.form.get("id_checker_employee")
    result = request.form.get("id_check_result")
    comment = (request.form.get("comment") or "").strip() or None

    if not checker or not result:
        flash("Для проверки нужно выбрать проверяющего и результат.", "error")
        return redirect(url_for("frame.view_frame", frame_token=frame_token))

    try:
        execute('''
            INSERT INTO "StageCheck"
            ("id_checker_employee","id_stage","id_check_result","comment","check_datetime")
            VALUES
            (%(checker)s,%(stage)s,%(res)s,%(comment)s,NOW());
        ''', {"checker": checker, "stage": id_stage, "res": result, "comment": comment})
        flash("Проверка сохранена. (AFTER-триггер мог обновить эпизод и график публикаций)", "ok")
    except Exception as e:
        flash(f"Ошибка при сохранении проверки: {e}", "error")

    return redirect(url_for("frame.view_frame", frame_token=frame_token))