import psycopg2
from flask import Blueprint, render_template, redirect, url_for, flash, request

from db import get_conn
from tokens import make_token, parse_token

bp = Blueprint("employee", __name__, url_prefix="/employees")


def fetch_all(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchall()


def fetch_one(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchone()

def execute(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})


def _employees_query_with_specialization(where_clause=""):
    return f'''
        SELECT
            e."id_employee",
            e."surname",
            e."name",
            e."patronymic",
            e."email",
            e."phone",
            e."birth_date",
            sp."specialization_name" AS specialization
        FROM "Employees" e
        LEFT JOIN "Spesialization" sp
               ON sp."id_spesialization" = e."id_spesialization"
        {where_clause}
        ORDER BY e."surname", e."name", e."patronymic";
    '''


def _employees_query_with_specialization_column(where_clause=""):
    return f'''
        SELECT
            e."id_employee",
            e."surname",
            e."name",
            e."patronymic",
            e."email",
            e."phone",
            e."birth_date",
            e."specialization" AS specialization
        FROM "Employees" e
        {where_clause}
        ORDER BY e."surname", e."name", e."patronymic";
    '''


def _search_clause(search_term: str, specialization_expr: str):
    if not search_term:
        return "", {}
    return (
        f'''
        WHERE (
            e."surname" ILIKE %(q)s
            OR e."name" ILIKE %(q)s
            OR COALESCE(e."patronymic", '') ILIKE %(q)s
            OR (e."surname" || ' ' || e."name" || ' ' || COALESCE(e."patronymic", '')) ILIKE %(q)s
            OR COALESCE(e."email", '') ILIKE %(q)s
            OR COALESCE(e."phone", '') ILIKE %(q)s
            OR COALESCE({specialization_expr}, '') ILIKE %(q)s
        )
        ''',
        {"q": f"%{search_term}%"},
    )


def _fetch_employees(search_term: str):
    where_clause, params = _search_clause(search_term, 'sp."specialization_name"')
    try:
        return fetch_all(_employees_query_with_specialization(where_clause), params)
    except psycopg2.Error:
        where_clause, params = _search_clause(search_term, 'e."specialization"')
        try:
            return fetch_all(_employees_query_with_specialization_column(where_clause), params)
        except psycopg2.Error:
            where_clause, params = _search_clause(search_term, "''")
            rows = fetch_all(f'''
                SELECT
                    e."id_employee",
                    e."surname",
                    e."name",
                    e."patronymic",
                    e."email",
                    e."phone",
                    e."birth_date"
                FROM "Employees" e
                {where_clause}
                ORDER BY e."surname", e."name", e."patronymic";
            ''', params)
            for r in rows:
                r["specialization"] = None
            return rows


def _fetch_employee(id_employee: int):
    try:
        return fetch_one(_employees_query_with_specialization('WHERE e."id_employee" = %(id_employee)s'), {"id_employee": id_employee})
    except psycopg2.Error:
        try:
            return fetch_one(_employees_query_with_specialization_column('WHERE e."id_employee" = %(id_employee)s'), {"id_employee": id_employee})
        except psycopg2.Error:
            row = fetch_one('''
                SELECT
                    e."id_employee",
                    e."surname",
                    e."name",
                    e."patronymic",
                    e."email",
                    e."phone",
                    e."birth_date"
                FROM "Employees" e
                WHERE e."id_employee" = %(id_employee)s;
            ''', {"id_employee": id_employee})
            if row:
                row["specialization"] = None
            return row


def _attach_token(row):
    row["token"] = make_token("employee", row["id_employee"])
    return row

def _fetch_specializations():
    try:
        return fetch_all('''
            SELECT "id_spesialization", "specialization_name"
            FROM "Spesialization"
            ORDER BY "specialization_name";
        ''')
    except psycopg2.Error:
        return []


@bp.get("")
def list_employees():
    search = request.args.get("q", "").strip()
    rows = [_attach_token(r) for r in _fetch_employees(search)]
    return render_template("employees_list.html", rows=rows, q=search)


@bp.get("/new")
def new_employee_form():
    specializations = _fetch_specializations()
    return render_template("employees_form.html", specializations=specializations)


@bp.post("/new")
def create_employee():
    data = {
        "surname": request.form.get("surname", "").strip(),
        "name": request.form.get("name", "").strip(),
        "patronymic": request.form.get("patronymic", "").strip() or None,
        "email": request.form.get("email", "").strip() or None,
        "phone": request.form.get("phone", "").strip() or None,
        "birth_date": request.form.get("birth_date") or None,
        "id_spesialization": request.form.get("id_spesialization") or None,
        "specialization": request.form.get("specialization", "").strip() or None,
    }

    if not data["surname"] or not data["name"]:
        flash("Фамилия и имя обязательны.", "error")
        return redirect(url_for("employee.new_employee_form"))

    try:
        execute('''
            INSERT INTO "Employees"
            ("surname","name","patronymic","email","phone","birth_date","id_spesialization")
            VALUES
            (%(surname)s,%(name)s,%(patronymic)s,%(email)s,%(phone)s,%(birth_date)s,%(id_spesialization)s);
        ''', data)
    except psycopg2.Error:
        execute('''
            INSERT INTO "Employees"
            ("surname","name","patronymic","email","phone","birth_date","specialization")
            VALUES
            (%(surname)s,%(name)s,%(patronymic)s,%(email)s,%(phone)s,%(birth_date)s,%(specialization)s);
        ''', data)

    flash("Сотрудник добавлен.", "ok")
    return redirect(url_for("employee.list_employees"))


@bp.get("/<token>")
def view_employee(token: str):
    try:
        id_employee = parse_token(token, "employee")
    except ValueError:
        flash("Неверная ссылка на сотрудника.", "error")
        return redirect(url_for("employee.list_employees"))

    emp = _fetch_employee(id_employee)
    if not emp:
        flash("Сотрудник не найден.", "error")
        return redirect(url_for("employee.list_employees"))

    load_rows = fetch_all('''
        SELECT
            s."id_stage",
            st."stage_type_name",
            ss."stage_status_name",
            s."planned_end_date",
            s."start_datetime",
            s."actual_end_datetime",
            COALESCE(p."project_name", '') AS project_name,
            COALESCE(ep."episode_name", '') AS episode_name,
            fr."frame_number_in_episode" AS frame_no,
            (
              SELECT dp."progress_percent"
              FROM "DailyProgress" dp
              WHERE dp."id_stage" = s."id_stage"
              ORDER BY dp."progress_date" DESC, dp."id_progress" DESC
              LIMIT 1
            ) AS last_progress_percent
        FROM "Stage" s
        JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
        JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        LEFT JOIN "Project" p ON p."id_project" = s."id_project"
        LEFT JOIN "Episode" ep ON ep."id_episode" = s."id_episode"
        LEFT JOIN "Frame" fr ON fr."id_frame" = s."id_frame"
        WHERE s."id_responsible_employee" = %(eid)s
        ORDER BY
          ss."stage_status_name" IN ('Принят','Завершён') ASC,
          s."planned_end_date" NULLS LAST,
          s."id_stage" DESC;
    ''', {"eid": id_employee})

    summary = fetch_one('''
        SELECT
          COUNT(*) AS total,
          COUNT(*) FILTER (WHERE ss."stage_status_name" NOT IN ('Принят','Завершён')) AS active,
          COUNT(*) FILTER (WHERE ss."stage_status_name" = 'Требует доработки') AS needs_rework
        FROM "Stage" s
        JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        WHERE s."id_responsible_employee" = %(eid)s;
    ''', {"eid": id_employee})

    specializations = _fetch_specializations()
    return render_template(
        "employees_view.html",
        emp=emp,
        token=token,
        load_rows=load_rows,
        summary=summary,
        specializations=specializations,
    )


@bp.post("/<token>/edit")
def update_employee(token: str):
    try:
        id_employee = parse_token(token, "employee")
    except ValueError:
        flash("Неверная ссылка на сотрудника.", "error")
        return redirect(url_for("employee.list_employees"))

    data = {
        "id_employee": id_employee,
        "surname": request.form.get("surname", "").strip(),
        "name": request.form.get("name", "").strip(),
        "patronymic": request.form.get("patronymic", "").strip() or None,
        "email": request.form.get("email", "").strip() or None,
        "phone": request.form.get("phone", "").strip() or None,
        "birth_date": request.form.get("birth_date") or None,
        "id_spesialization": request.form.get("id_spesialization") or None,
        "specialization": request.form.get("specialization", "").strip() or None,
    }

    if not data["surname"] or not data["name"]:
        flash("Фамилия и имя обязательны.", "error")
        return redirect(url_for("employee.view_employee", token=token))

    try:
        execute('''
            UPDATE "Employees"
            SET "surname"=%(surname)s,
                "name"=%(name)s,
                "patronymic"=%(patronymic)s,
                "email"=%(email)s,
                "phone"=%(phone)s,
                "birth_date"=%(birth_date)s,
                "id_spesialization"=%(id_spesialization)s
            WHERE "id_employee"=%(id_employee)s;
        ''', data)
    except psycopg2.Error:
        execute('''
            UPDATE "Employees"
            SET "surname"=%(surname)s,
                "name"=%(name)s,
                "patronymic"=%(patronymic)s,
                "email"=%(email)s,
                "phone"=%(phone)s,
                "birth_date"=%(birth_date)s,
                "specialization"=%(specialization)s
            WHERE "id_employee"=%(id_employee)s;
        ''', data)

    flash("Данные сотрудника обновлены.", "ok")
    return redirect(url_for("employee.view_employee", token=token))


@bp.post("/<token>/delete")
def delete_employee(token: str):
    try:
        id_employee = parse_token(token, "employee")
    except ValueError:
        flash("Неверная ссылка на сотрудника.", "error")
        return redirect(url_for("employee.list_employees"))

    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute('''
                UPDATE "Stage"
                SET "id_responsible_employee" = NULL
                WHERE "id_responsible_employee" = %(eid)s;
            ''', {"eid": id_employee})
            cur.execute('''
                DELETE FROM "DailyProgress" WHERE "id_employee" = %(eid)s;
            ''', {"eid": id_employee})
            cur.execute('''
                DELETE FROM "StageCheck" WHERE "id_checker_employee" = %(eid)s;
            ''', {"eid": id_employee})
            cur.execute('''
                DELETE FROM "Employees" WHERE "id_employee" = %(eid)s;
            ''', {"eid": id_employee})
        flash("Сотрудник удалён.", "ok")
    except Exception as err:
        flash(f"Ошибка при удалении сотрудника: {err}", "error")

    return redirect(url_for("employee.list_employees"))
