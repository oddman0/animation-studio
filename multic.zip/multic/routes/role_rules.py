import psycopg2

from db import get_conn


ROLE_RULES = {
    "разработка идеи и сценария": {"сценарист"},
    "концепт-арт и дизайн": {"художник-постановщик"},
    "создание раскадровки": {"художник-постановщик"},
    "аниматик / превизуализация": {"художник-постановщик"},
    "озвучивание": {"актёр озвучивания"},
    "звук и музыка": {"звукорежиссёр"},
    "финальная приёмка эпизода": {"режиссёр"},
    "моделирование": {"3d-моделлер"},
    "анимация": {"аниматор"},
    "композитинг": {"компоузер (композитинг)"},
    "визуальные эффекты (vfx)": {"vfx-специалист"},
    "техническая подготовка": {"технический художник"},
    "рендеринг": {"специалист по рендерингу"},
}


def _normalize(value: str | None) -> str:
    if not value:
        return ""
    return " ".join(value.lower().split())


def normalize_value(value: str | None) -> str:
    return _normalize(value)


def allowed_specializations(stage_type_name: str | None) -> set[str] | None:
    if not stage_type_name:
        return None
    return ROLE_RULES.get(_normalize(stage_type_name))


def _fetch_stage_type_name(stage_id: int) -> str | None:
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute('''
            SELECT st."stage_type_name"
            FROM "Stage" s
            JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
            WHERE s."id_stage" = %(sid)s;
        ''', {"sid": stage_id})
        row = cur.fetchone()
        return row["stage_type_name"] if row else None


def _fetch_employee_specialization(employee_id: int) -> str | None:
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute('''
                SELECT sp."specialization_name" AS specialization
                FROM "Employees" e
                LEFT JOIN "Spesialization" sp
                       ON sp."id_spesialization" = e."id_spesialization"
                WHERE e."id_employee" = %(eid)s;
            ''', {"eid": employee_id})
            row = cur.fetchone()
            return row["specialization"] if row else None
    except psycopg2.Error:
        return None


def validate_stage_responsible(stage_id: int, employee_id: int) -> tuple[bool, str | None]:
    stage_type_name = _fetch_stage_type_name(stage_id)
    if not stage_type_name:
        return False, "Этап не найден."

    allowed = ROLE_RULES.get(_normalize(stage_type_name))
    if not allowed:
        return False, f"Для этапа «{stage_type_name}» нет правила назначения."

    specialization = _fetch_employee_specialization(employee_id)
    if not specialization:
        return False, "У сотрудника не указана специализация."

    normalized_spec = _normalize(specialization)
    if normalized_spec not in allowed:
        needed = ", ".join(sorted(allowed))
        return (
            False,
            f"Нельзя назначить «{specialization}» на этап «{stage_type_name}». Требуется: {needed}.",
        )

    return True, None
