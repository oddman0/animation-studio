from datetime import date, timedelta

from flask import Blueprint, render_template, request, redirect, url_for, flash
from db import get_conn
from tokens import make_token, parse_token
from routes.role_rules import validate_stage_responsible, allowed_specializations, normalize_value

bp = Blueprint("project", __name__, url_prefix="/projects")

def ensure_project_stages(id_project: int) -> bool:
    """Создаёт этапы (Stage) для проекта, если их нет. Возвращает True, если этапы добавлены."""
    cnt = fetch_one('SELECT COUNT(*)::int AS c FROM "Stage" WHERE "id_project"=%(pid)s AND "id_episode" IS NULL AND "id_frame" IS NULL;', {"pid": id_project})
    if cnt and cnt.get("c", 0) > 0:
        return False

    emp = fetch_one('''
        SELECT "id_employee"
        FROM "Employees"
        WHERE COALESCE("is_active", FALSE) = TRUE
        ORDER BY "id_employee"
        LIMIT 1;
    ''')
    if not emp:
        emp = fetch_one('SELECT "id_employee" FROM "Employees" ORDER BY "id_employee" LIMIT 1;')
    if not emp:
        return False

    st = fetch_one('''
        SELECT "id_stage_status"
        FROM "StageStatus"
        WHERE "stage_status_name" = 'Не начат'
        LIMIT 1;
    ''')
    if not st:
        st = fetch_one('SELECT "id_stage_status" FROM "StageStatus" ORDER BY "id_stage_status" LIMIT 1;')
    if not st:
        return False

    planned = fetch_one('SELECT "planned_end_date" FROM "Project" WHERE "id_project"=%(pid)s;', {"pid": id_project})

    execute('''
        INSERT INTO "Stage"
        ("id_project","id_episode","id_frame",
         "id_responsible_employee","stage_type_id","id_stage_status",
         "start_datetime","actual_end_datetime","planned_end_date")
        SELECT
          %(pid)s, NULL, NULL,
          %(emp)s, stt."stage_type_id", %(sid)s,
          NULL, NULL, %(planned)s
        FROM "StageType" stt
        WHERE LOWER(COALESCE(stt."stage_level", '')) = 'project'
        ORDER BY stt."execution_order" NULLS LAST, stt."stage_type_id";
    ''', {"pid": id_project, "emp": emp["id_employee"], "sid": st["id_stage_status"], "planned": (planned or {}).get("planned_end_date")})
    return True


# --- Helpers ---
def fetch_all(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchall()

def fetch_one(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchone()

def execute(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})

def _token_for_row(row):
    row["token"] = make_token("project", row["id_project"])
    return row

def _progress_project(id_project: int):
    """Возвращает прогресс проекта (общий и на сегодня).
    Прогресс считается как средний процент по всем этапам
    (включая уровни проекта, эпизодов и кадров).
    Ежедневный прогресс — разница прогресса на сегодня и вчера.
    """
    def _overall_as_of(as_of_date: date) -> float:
        row = fetch_one('''
            WITH stage_project AS (
              SELECT
                s."id_stage",
                s."id_stage_status",
                COALESCE(s."id_project", e."id_project", e2."id_project") AS id_project
              FROM "Stage" s
              LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
              LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
              LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
              WHERE s."id_project" = %(pid)s
                 OR e."id_project"  = %(pid)s
                 OR e2."id_project" = %(pid)s
            ),
            last_progress AS (
              SELECT
                dp."id_stage",
                dp."progress_percent",
                ROW_NUMBER() OVER (PARTITION BY dp."id_stage" ORDER BY dp."progress_date" DESC, dp."id_progress" DESC) AS rn
              FROM "DailyProgress" dp
              JOIN stage_project sp ON sp."id_stage" = dp."id_stage"
              WHERE dp."progress_date" <= %(as_of)s
            ),
            stage_p AS (
              SELECT
                sp."id_stage",
                COALESCE(
                  lp."progress_percent"::numeric,
                  CASE
                    WHEN ss."stage_status_name" ILIKE '%%не начат%%' THEN 0
                    WHEN ss."stage_status_name" ILIKE '%%в работе%%' THEN 50
                    WHEN ss."stage_status_name" ILIKE '%%доработ%%' THEN 70
                    WHEN ss."stage_status_name" ILIKE '%%провер%%' THEN 90
                    WHEN ss."stage_status_name" ILIKE '%%заверш%%'
                      OR ss."stage_status_name" ILIKE '%%принят%%' THEN 100
                    ELSE 0
                  END::numeric
                ) AS p
              FROM stage_project sp
              LEFT JOIN last_progress lp ON lp."id_stage" = sp."id_stage" AND lp.rn = 1
              LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = sp."id_stage_status"
            )
            SELECT COALESCE(ROUND(AVG(p), 2), 0) AS overall_percent
            FROM stage_p;
        ''', {"pid": id_project, "as_of": as_of_date})
        return float(row["overall_percent"]) if row and row["overall_percent"] is not None else 0.0

    overall = _overall_as_of(date.today())

    daily_row = fetch_one('''
        WITH stage_project AS (
          SELECT s."id_stage"
          FROM "Stage" s
          LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
          LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
          LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
          WHERE s."id_project" = %(pid)s
             OR e."id_project"  = %(pid)s
             OR e2."id_project" = %(pid)s
        ),
        today_dp AS (
          SELECT
            dp."id_stage",
            dp."progress_percent",
            ROW_NUMBER() OVER (PARTITION BY dp."id_stage" ORDER BY dp."progress_date" DESC, dp."id_progress" DESC) AS rn
          FROM "DailyProgress" dp
          JOIN stage_project sp ON sp."id_stage" = dp."id_stage"
          WHERE dp."progress_date" = CURRENT_DATE
        )
        SELECT
          COUNT(*) AS total_stages,
          COALESCE(SUM(COALESCE(t.progress_percent, 0)), 0) AS today_sum
        FROM stage_project sp
        LEFT JOIN today_dp t ON t."id_stage" = sp."id_stage" AND t.rn = 1;
    ''', {"pid": id_project})

    total = float(daily_row["total_stages"]) if daily_row and daily_row["total_stages"] is not None else 0.0
    today_sum = float(daily_row["today_sum"]) if daily_row and daily_row["today_sum"] is not None else 0.0
    today = round((today_sum / total), 2) if total > 0 else 0.0

    return {"overall": round(overall, 2), "today": today}

@bp.get("/")
def list_projects():
    rows = fetch_all('''
        SELECT 
            p."id_project",
            p."project_name",
            p."start_date",
            p."planned_end_date",
            p."actual_end_date",
            ps."project_status_name"
        FROM "Project" p
        LEFT JOIN "ProjectStatus" ps
               ON ps."id_project_status" = p."id_project_status"
        ORDER BY p."id_project" DESC;
    ''')
    # attach tokens + progress
    out = []
    for r in rows:
        r = _token_for_row(r)
        pr = _progress_project(r["id_project"])
        r["progress_overall"] = pr["overall"]
        r["progress_today"] = pr["today"]
        out.append(r)
    return render_template("projects_list.html", rows=out)

@bp.get("/new")
def new_project_form():
    statuses = fetch_all('SELECT "id_project_status", "project_status_name" FROM "ProjectStatus" ORDER BY 1;')
    return render_template("projects_form.html", mode="new", statuses=statuses, item=None, token=None)

@bp.post("/new")
def create_project():
    data = {
        "project_name": request.form.get("project_name", "").strip(),
        "description": request.form.get("description", "").strip() or None,
        "start_date": request.form.get("start_date") or None,
        "planned_end_date": request.form.get("planned_end_date") or None,
        "actual_end_date": request.form.get("actual_end_date") or None,
        "id_project_status": request.form.get("id_project_status") or None,
    }

    if not data["project_name"]:
        flash("Поле «Название проекта» обязательно.", "error")
        return redirect(url_for("project.new_project_form"))

    execute('''
        INSERT INTO "Project"
        ("project_name","description","start_date","planned_end_date","actual_end_date","id_project_status")
        VALUES
        (%(project_name)s,%(description)s,%(start_date)s,%(planned_end_date)s,%(actual_end_date)s,%(id_project_status)s);
    ''', data)

    flash("Проект создан.", "ok")
    return redirect(url_for("project.list_projects"))

@bp.get("/<token>")
def view_project(token: str):
    try:
        id_project = parse_token(token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    item = fetch_one('''
        SELECT 
            p.*,
            ps."project_status_name"
        FROM "Project" p
        LEFT JOIN "ProjectStatus" ps
               ON ps."id_project_status" = p."id_project_status"
        WHERE p."id_project" = %(id_project)s;
    ''', {"id_project": id_project})
    # Если этапов проекта нет — создаём автоматически
    ensure_project_stages(id_project)


    if not item:
        flash("Проект не найден.", "error")
        return redirect(url_for("project.list_projects"))

    progress = _progress_project(id_project)

    statuses = fetch_all('SELECT "id_project_status","project_status_name" FROM "ProjectStatus" ORDER BY 1;')

    episodes = fetch_all('''
        SELECT 
            e."id_episode",
            e."episode_number_in_project",
            e."episode_name",
            e."planned_release_date",
            e."actual_release_date",
            e."ready_for_release_flag",
            es."episode_status_name"
        FROM "Episode" e
        LEFT JOIN "EpisodeStatus" es ON es."id_episode_status" = e."id_episode_status"
        WHERE e."id_project" = %(pid)s
        ORDER BY e."episode_number_in_project";
    ''', {"pid": id_project})

    for e in episodes:
        e["token"] = make_token("episode", e["id_episode"])

    item_token = token  # keep same token for URLs/forms
    project_stages = fetch_all('''
        SELECT
            s."id_stage",
            s."id_responsible_employee",
            st."stage_type_name",
            COALESCE(ss."stage_status_name", '—') AS stage_status_name,
            s."planned_end_date",
            COALESCE((emp."surname" || ' ' || emp."name"), '—') AS responsible,
            (
              SELECT dp."progress_percent"
              FROM "DailyProgress" dp
              WHERE dp."id_stage" = s."id_stage"
              ORDER BY dp."progress_date" DESC, dp."id_progress" DESC
              LIMIT 1
            ) AS last_progress_percent
        FROM "Stage" s
        JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
        LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        LEFT JOIN "Employees" emp ON emp."id_employee" = s."id_responsible_employee"
        WHERE s."id_project" = %(pid)s
        ORDER BY st."execution_order", s."id_stage";
    ''', {"pid": id_project})

    for s in project_stages:
        s["token"] = make_token("stage", s["id_stage"])

    try:
        employees = fetch_all('''
            SELECT
                e."id_employee",
                (e."surname" || ' ' || e."name") AS fio,
                sp."specialization_name" AS specialization
            FROM "Employees" e
            LEFT JOIN "Spesialization" sp
                   ON sp."id_spesialization" = e."id_spesialization"
            WHERE COALESCE(e."is_active", TRUE) = TRUE
            ORDER BY e."surname","name";
        ''')
    except Exception:
        employees = fetch_all('''
            SELECT
                e."id_employee",
                (e."surname" || ' ' || e."name") AS fio,
                NULL AS specialization
            FROM "Employees" e
            WHERE COALESCE(e."is_active", TRUE) = TRUE
            ORDER BY e."surname","name";
        ''')

    employees_by_stage = {}
    for s in project_stages:
        allowed = allowed_specializations(s.get("stage_type_name"))
        if allowed:
            employees_by_stage[s["id_stage"]] = [
                e for e in employees if normalize_value(e.get("specialization")) in allowed
            ]
        else:
            employees_by_stage[s["id_stage"]] = employees

# Этапы проекта/эпизодов/кадров для отображения на странице проекта (все привязаны по id_project)
    stage_statuses = fetch_all('SELECT "id_stage_status","stage_status_name" FROM "StageStatus" ORDER BY 1;')

    stages_all = fetch_all('''
      SELECT
        s."id_stage",
        s."id_episode",
        s."id_frame",
        stt."stage_type_name" AS stage_type_name,
        ss."stage_status_name" AS stage_status_name,
        (e."surname" || ' ' || e."name") AS responsible,
        COALESCE(dp_last."progress_percent", CASE
            WHEN ss."stage_status_name" ILIKE '%%не начат%%' THEN 0
            WHEN ss."stage_status_name" ILIKE '%%в работе%%' THEN 50
            WHEN ss."stage_status_name" ILIKE '%%доработ%%' THEN 70
            WHEN ss."stage_status_name" ILIKE '%%провер%%' THEN 90
            WHEN ss."stage_status_name" ILIKE '%%заверш%%' OR ss."stage_status_name" ILIKE '%%готов%%' OR ss."stage_status_name" ILIKE '%%принят%%' THEN 100
            ELSE 0
          END) AS last_progress_percent,
        s."planned_end_date"
      FROM "Stage" s
      JOIN "StageType" stt ON stt."stage_type_id" = s."stage_type_id"
      LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
      LEFT JOIN "Employees" e ON e."id_employee" = s."id_responsible_employee"
      LEFT JOIN LATERAL (
          SELECT dp."progress_percent"
          FROM "DailyProgress" dp
          WHERE dp."id_stage" = s."id_stage"
          ORDER BY dp."progress_date" DESC, dp."id_progress" DESC
          LIMIT 1
      ) dp_last ON TRUE
      WHERE s."id_project" = %(pid)s
      ORDER BY
        (CASE WHEN s."id_episode" IS NULL AND s."id_frame" IS NULL THEN 1
              WHEN s."id_episode" IS NOT NULL AND s."id_frame" IS NULL THEN 2
              ELSE 3 END),
        stt."execution_order" NULLS LAST, s."id_stage";
    ''', {"pid": id_project})

    for s in stages_all:
        s["token"] = make_token("stage", s["id_stage"])

    episode_stages = [s for s in stages_all if s.get("id_episode") and not s.get("id_frame")]
    frame_stages = [s for s in stages_all if s.get("id_frame")]

    return render_template(
        "projects_view.html",
        item=item,
        token=item_token,
        progress=progress,
        episodes=episodes,
        project_stages=project_stages,
        employees=employees,
        employees_by_stage=employees_by_stage,
        stage_statuses=stage_statuses,
        stages_all=stages_all,
        episode_stages=episode_stages,
        frame_stages=frame_stages,
        statuses=statuses,
    )





@bp.post("/stage/<stage_token>/status")
def update_project_stage_status(stage_token: str):
    try:
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка на этап.", "error")
        return redirect(url_for("project.list_projects"))

    new_status = request.form.get("id_stage_status") or None

    try:
        execute('''
            UPDATE "Stage"
            SET "id_stage_status" = %(sid)s
            WHERE "id_stage" = %(stid)s;
        ''', {"sid": new_status, "stid": id_stage})

        execute('''
            INSERT INTO "DailyProgress" ("id_employee","id_stage","progress_date","progress_percent")
            SELECT
              s."id_responsible_employee",
              s."id_stage",
              CURRENT_DATE,
              CASE
        WHEN ss."stage_status_name" ILIKE '%%не начат%%' THEN 0
        WHEN ss."stage_status_name" ILIKE '%%в работе%%' THEN 50
        WHEN ss."stage_status_name" ILIKE '%%доработ%%' THEN 70
        WHEN ss."stage_status_name" ILIKE '%%провер%%' THEN 90
        WHEN ss."stage_status_name" ILIKE '%%заверш%%' OR ss."stage_status_name" ILIKE '%%готов%%' OR ss."stage_status_name" ILIKE '%%принят%%' THEN 100
        ELSE 0
      END AS progress_percent
            FROM "Stage" s
            LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
            WHERE s."id_stage" = %(stid)s;
        ''', {"stid": id_stage})

        flash("Статус этапа обновлён.", "ok")
    except Exception as err:
        flash(f"Ошибка при обновлении статуса этапа: {err}", "error")

    return redirect(request.form.get("next") or url_for("project.list_projects"))
@bp.post("/<token>/status")
def update_project_status(token: str):
    try:
        id_project = parse_token(token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    new_status = request.form.get("id_project_status") or None

    try:
        execute('''
            UPDATE "Project"
            SET "id_project_status" = %(sid)s
            WHERE "id_project" = %(pid)s;
        ''', {"sid": new_status, "pid": id_project})
        flash("Статус проекта обновлён. (Триггеры БД выполнены)", "ok")
    except Exception as e:
        flash(f"Ошибка при обновлении статуса: {e}", "error")

    return redirect(url_for("project.view_project", token=token))
@bp.post("/<token>/stages/<stage_token>/responsible")
def update_project_stage_responsible(token: str, stage_token: str):
    try:
        id_project = parse_token(token, "project")
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка.", "error")
        return redirect(url_for("project.list_projects"))

    employee_id = request.form.get("id_responsible_employee") or None
    if employee_id:
        ok, error = validate_stage_responsible(id_stage, int(employee_id))
        if not ok:
            flash(error, "error")
            return redirect(url_for("project.view_project", token=token))
    execute('''
        UPDATE "Stage"
        SET "id_responsible_employee" = %(eid)s
        WHERE "id_stage" = %(id_stage)s AND "id_project" = %(pid)s;
    ''', {"eid": employee_id, "id_stage": id_stage, "pid": id_project})

    flash("Ответственный назначен.", "ok")
    return redirect(url_for("project.view_project", token=token))

@bp.get("/<token>/edit")
def edit_project_form(token: str):
    try:
        id_project = parse_token(token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    item = fetch_one('SELECT * FROM "Project" WHERE "id_project"=%(id_project)s;', {"id_project": id_project})
    if not item:
        flash("Проект не найден.", "error")
        return redirect(url_for("project.list_projects"))

    statuses = fetch_all('SELECT "id_project_status", "project_status_name" FROM "ProjectStatus" ORDER BY 1;')
    return render_template("projects_form.html", mode="edit", statuses=statuses, item=item, token=token)

@bp.post("/<token>/edit")
def update_project(token: str):
    try:
        id_project = parse_token(token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    data = {
        "id_project": id_project,
        "project_name": request.form.get("project_name", "").strip(),
        "description": request.form.get("description", "").strip() or None,
        "start_date": request.form.get("start_date") or None,
        "planned_end_date": request.form.get("planned_end_date") or None,
        "actual_end_date": request.form.get("actual_end_date") or None,
        "id_project_status": request.form.get("id_project_status") or None,
    }

    if not data["project_name"]:
        flash("Поле «Название проекта» обязательно.", "error")
        return redirect(url_for("project.edit_project_form", token=token))

    execute('''
        UPDATE "Project"
        SET "project_name"=%(project_name)s,
            "description"=%(description)s,
            "start_date"=%(start_date)s,
            "planned_end_date"=%(planned_end_date)s,
            "actual_end_date"=%(actual_end_date)s,
            "id_project_status"=%(id_project_status)s
        WHERE "id_project"=%(id_project)s;
    ''', data)

    flash("Изменения сохранены.", "ok")
    return redirect(url_for("project.view_project", token=token))

@bp.post("/<token>/delete")
def delete_project(token: str):
    try:
        id_project = parse_token(token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute('''
                DELETE FROM "StageStatusHistory"
                WHERE "id_stage" IN (
                    SELECT s."id_stage"
                    FROM "Stage" s
                    LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
                    LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
                    LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
                    WHERE s."id_project" = %(pid)s
                       OR e."id_project" = %(pid)s
                       OR e2."id_project" = %(pid)s
                );
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "StageCheck"
                WHERE "id_stage" IN (
                    SELECT s."id_stage"
                    FROM "Stage" s
                    LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
                    LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
                    LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
                    WHERE s."id_project" = %(pid)s
                       OR e."id_project" = %(pid)s
                       OR e2."id_project" = %(pid)s
                );
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "DailyProgress"
                WHERE "id_stage" IN (
                    SELECT s."id_stage"
                    FROM "Stage" s
                    LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
                    LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
                    LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
                    WHERE s."id_project" = %(pid)s
                       OR e."id_project" = %(pid)s
                       OR e2."id_project" = %(pid)s
                );
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "Stage" s
                WHERE s."id_project" = %(pid)s
                   OR s."id_episode" IN (
                       SELECT e."id_episode" FROM "Episode" e WHERE e."id_project" = %(pid)s
                   )
                   OR s."id_frame" IN (
                       SELECT f."id_frame"
                       FROM "Frame" f
                       JOIN "Episode" e ON e."id_episode" = f."id_episode"
                       WHERE e."id_project" = %(pid)s
                   );
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "PublicationSchedule"
                WHERE "id_episode" IN (
                    SELECT e."id_episode" FROM "Episode" e WHERE e."id_project" = %(pid)s
                );
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "Frame"
                WHERE "id_episode" IN (
                    SELECT e."id_episode" FROM "Episode" e WHERE e."id_project" = %(pid)s
                );
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "Episode" WHERE "id_project" = %(pid)s;
            ''', {"pid": id_project})
            cur.execute('''
                DELETE FROM "Project" WHERE "id_project" = %(pid)s;
            ''', {"pid": id_project})
        flash("Проект удалён.", "ok")
    except Exception as err:
        flash(f"Ошибка при удалении проекта: {err}", "error")
    return redirect(url_for("project.list_projects"))
