from flask import Blueprint, render_template, request, redirect, url_for, flash
from db import get_conn
from tokens import make_token, parse_token
from routes.role_rules import validate_stage_responsible, allowed_specializations, normalize_value

bp = Blueprint("episode", __name__, url_prefix="/episodes")


def ensure_episode_stages(id_episode: int, planned_release_date=None) -> bool:
    """Создаёт этапы (Stage) для эпизода, если их нет. Возвращает True, если этапы добавлены."""
    cnt = fetch_one('SELECT COUNT(*)::int AS c FROM "Stage" WHERE "id_episode"=%(eid)s AND "id_frame" IS NULL;', {"eid": id_episode})
    if cnt and cnt.get("c", 0) > 0:
        return False

    emp = fetch_one('''
        SELECT "id_employee"
        FROM "Employees"
        WHERE COALESCE("is_active", FALSE) = TRUE
        ORDER BY "id_employee"
        LIMIT 1;
    ''')
    if not emp:
        emp = fetch_one('SELECT "id_employee" FROM "Employees" ORDER BY "id_employee" LIMIT 1;')
    if not emp:
        return False

    st = fetch_one('''
        SELECT "id_stage_status"
        FROM "StageStatus"
        WHERE "stage_status_name" = 'Не начат'
        LIMIT 1;
    ''')
    if not st:
        st = fetch_one('SELECT "id_stage_status" FROM "StageStatus" ORDER BY "id_stage_status" LIMIT 1;')
    if not st:
        return False

    execute('''
        INSERT INTO "Stage"
        ("id_project","id_episode","id_frame",
         "id_responsible_employee","stage_type_id","id_stage_status",
         "start_datetime","actual_end_datetime","planned_end_date")
        SELECT
          NULL, %(eid)s, NULL,
          %(emp)s, stt."stage_type_id", %(sid)s,
          NULL, NULL, %(planned)s
        FROM "StageType" stt
        WHERE LOWER(COALESCE(stt."stage_level", '')) = 'episode'
        ORDER BY stt."execution_order" NULLS LAST, stt."stage_type_id";
    ''', {"eid": id_episode, "emp": emp["id_employee"], "sid": st["id_stage_status"], "planned": planned_release_date})
    return True

def fetch_all(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchall()

def fetch_one(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchone()

def execute(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})

@bp.get("/<episode_token>")
def view_episode(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    ep = fetch_one('''
        SELECT 
            e.*,
            es."episode_status_name",
            p."project_name"
        FROM "Episode" e
        LEFT JOIN "EpisodeStatus" es ON es."id_episode_status" = e."id_episode_status"
        JOIN "Project" p ON p."id_project" = e."id_project"
        WHERE e."id_episode" = %(eid)s;
    ''', {"eid": id_episode})

    if not ep:
        flash("Эпизод не найден.", "error")
        return redirect(url_for("project.list_projects"))

    project_token = make_token("project", ep["id_project"])

    # Если этапов эпизода нет — создаём автоматически
    ensure_episode_stages(id_episode, ep.get("planned_release_date"))

    frames = fetch_all('''
        SELECT 
            f."id_frame",
            f."frame_number_in_episode",
            f."planned_due_date",
            f."actual_done_date"
        FROM "Frame" f
        WHERE f."id_episode" = %(eid)s
        ORDER BY f."frame_number_in_episode";
    ''', {"eid": id_episode})

    for fr in frames:
        fr["token"] = make_token("frame", fr["id_frame"])

    pub = fetch_all('''
        SELECT
          ps."id_publication_schedule",
          pstat."publication_status_name",
          ps."planned_publication_date",
          ps."actual_publication_date"
        FROM "PublicationSchedule" ps
        JOIN "PublicationStatus" pstat ON pstat."id_publication_status" = ps."id_publication_status"
        WHERE ps."id_episode" = %(eid)s
        ORDER BY ps."planned_publication_date", ps."id_publication_schedule";
    ''', {"eid": id_episode})

    episode_stages = fetch_all('''
        SELECT
            s."id_stage",
            s."id_responsible_employee",
            st."stage_type_name",
            COALESCE(ss."stage_status_name", '—') AS stage_status_name,
            s."planned_end_date",
            COALESCE((emp."surname" || ' ' || emp."name"), '—') AS responsible,
            (
              SELECT dp."progress_percent"
              FROM "DailyProgress" dp
              WHERE dp."id_stage" = s."id_stage"
              ORDER BY dp."progress_date" DESC, dp."id_progress" DESC
              LIMIT 1
            ) AS last_progress_percent
        FROM "Stage" s
        JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
        LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        LEFT JOIN "Employees" emp ON emp."id_employee" = s."id_responsible_employee"
        WHERE s."id_episode" = %(eid)s
        ORDER BY st."execution_order", s."id_stage";
    ''', {"eid": id_episode})

    for s in episode_stages:
        s["token"] = make_token("stage", s["id_stage"])

    statuses = fetch_all('SELECT "id_episode_status","episode_status_name" FROM "EpisodeStatus" ORDER BY 1;')

    try:
        employees = fetch_all('''
            SELECT
                e."id_employee",
                (e."surname" || ' ' || e."name") AS fio,
                sp."specialization_name" AS specialization
            FROM "Employees" e
            LEFT JOIN "Spesialization" sp
                   ON sp."id_spesialization" = e."id_spesialization"
            WHERE COALESCE(e."is_active", TRUE) = TRUE
            ORDER BY e."surname","name";
        ''')
    except Exception:
        employees = fetch_all('''
            SELECT
                e."id_employee",
                (e."surname" || ' ' || e."name") AS fio,
                NULL AS specialization
            FROM "Employees" e
            WHERE COALESCE(e."is_active", TRUE) = TRUE
            ORDER BY e."surname","name";
        ''')

    employees_by_stage = {}
    for s in episode_stages:
        allowed = allowed_specializations(s.get("stage_type_name"))
        if allowed:
            employees_by_stage[s["id_stage"]] = [
                e for e in employees if normalize_value(e.get("specialization")) in allowed
            ]
        else:
            employees_by_stage[s["id_stage"]] = employees

    stage_statuses = fetch_all('SELECT "id_stage_status","stage_status_name" FROM "StageStatus" ORDER BY 1;')

    return render_template(
        "episodes_view.html",
        ep=ep,
        episode_token=episode_token,
        project_token=project_token,
        frames=frames,
        pub=pub,
        episode_stages=episode_stages,
        employees=employees,
        employees_by_stage=employees_by_stage,
        stage_statuses=stage_statuses,
        statuses=statuses
    )


@bp.post("/<episode_token>/stages/<stage_token>/responsible")
def update_episode_stage_responsible(episode_token: str, stage_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка.", "error")
        return redirect(url_for("project.list_projects"))

    employee_id = request.form.get("id_responsible_employee") or None
    if employee_id:
        ok, error = validate_stage_responsible(id_stage, int(employee_id))
        if not ok:
            flash(error, "error")
            return redirect(url_for("episode.view_episode", episode_token=episode_token))
    execute('''
        UPDATE "Stage"
        SET "id_responsible_employee" = %(eid)s
        WHERE "id_stage" = %(id_stage)s AND "id_episode" = %(eid2)s;
    ''', {"eid": employee_id, "id_stage": id_stage, "eid2": id_episode})

    flash("Ответственный назначен.", "ok")
    return redirect(url_for("episode.view_episode", episode_token=episode_token))



@bp.post("/<episode_token>/stages/<stage_token>/status")
def update_episode_stage_status(episode_token: str, stage_token: str):
    """Обновление статуса этапа эпизода + фиксация прогресса в DailyProgress.
    Это нужно, чтобы прогресс в интерфейсе менялся автоматически после переключения статуса.
    """
    try:
        id_episode = parse_token(episode_token, "episode")
        id_stage = parse_token(stage_token, "stage")
    except ValueError:
        flash("Неверная ссылка.", "error")
        return redirect(url_for("project.list_projects"))

    id_stage_status = request.form.get("id_stage_status") or None

    # Маппинг статуса -> процент прогресса (можно подстроить под твою шкалу)
    def status_to_progress(name: str | None) -> int:
        if not name:
            return 0
        n = name.lower()
        if "не нач" in n:
            return 0
        if "в работ" in n:
            return 50
        if "требует" in n or "доработ" in n:
            return 70
        if "заверш" in n or "готов" in n:
            return 100
        return 0

    try:
        # обновляем статус
        execute('''
            UPDATE "Stage"
            SET "id_stage_status" = %(sid)s
            WHERE "id_stage" = %(st)s AND "id_episode" = %(ep)s;
        ''', {"sid": id_stage_status, "st": id_stage, "ep": id_episode})

        # определяем имя статуса, чтобы посчитать процент
        ss = fetch_one('''
            SELECT "stage_status_name"
            FROM "StageStatus"
            WHERE "id_stage_status" = %(sid)s;
        ''', {"sid": id_stage_status})
        pct = status_to_progress(ss["stage_status_name"] if ss else None)

        # фиксируем прогресс на сегодня (новая запись)
        execute('''
            INSERT INTO "DailyProgress" ("id_employee","id_stage","progress_date","progress_percent")
            VALUES (
                (SELECT "id_responsible_employee" FROM "Stage" WHERE "id_stage"=%(st)s),
                %(st)s,
                CURRENT_DATE,
                %(pct)s
            );
        ''', {"st": id_stage, "pct": pct})

        flash(f"Статус этапа обновлён, прогресс: {pct}%.", "ok")
    except Exception as e:
        flash(f"Ошибка при обновлении статуса этапа: {e}", "error")

    return redirect(url_for("episode.view_episode", episode_token=episode_token))
@bp.post("/<episode_token>/status")
def update_episode_status(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    new_status = request.form.get("id_episode_status") or None
    try:
        execute('''
            UPDATE "Episode"
            SET "id_episode_status" = %(sid)s
            WHERE "id_episode" = %(eid)s;
        ''', {"sid": new_status, "eid": id_episode})
        flash("Статус эпизода обновлён. (Триггеры БД выполнены)", "ok")
    except Exception as e:
        flash(f"Ошибка при обновлении статуса: {e}", "error")

    return redirect(url_for("episode.view_episode", episode_token=episode_token))

@bp.get("/new/<project_token>")
def new_episode_form(project_token: str):
    try:
        id_project = parse_token(project_token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    project = fetch_one('SELECT "id_project","project_name" FROM "Project" WHERE "id_project"=%(pid)s;', {"pid": id_project})
    if not project:
        flash("Проект не найден.", "error")
        return redirect(url_for("project.list_projects"))

    statuses = fetch_all('SELECT "id_episode_status", "episode_status_name" FROM "EpisodeStatus" ORDER BY 1;')
    return render_template("episodes_form.html", mode="new", project=project, project_token=project_token, statuses=statuses, ep=None, episode_token=None)

@bp.post("/new/<project_token>")
def create_episode(project_token: str):
    try:
        id_project = parse_token(project_token, "project")
    except ValueError:
        flash("Неверная ссылка на проект.", "error")
        return redirect(url_for("project.list_projects"))

    data = {
        "id_project": id_project,
        "episode_name": request.form.get("episode_name","").strip(),
        "episode_number_in_project": request.form.get("episode_number_in_project") or None,
        "planned_release_date": request.form.get("planned_release_date") or None,
        "actual_release_date": request.form.get("actual_release_date") or None,
        "ready_for_release_flag": True if request.form.get("ready_for_release_flag") == "on" else False,
        "ready_for_release_date": request.form.get("ready_for_release_date") or None,
        "id_episode_status": request.form.get("id_episode_status") or None,
    }

    if not data["episode_name"]:
        flash("Поле «Название эпизода» обязательно.", "error")
        return redirect(url_for("episode.new_episode_form", project_token=project_token))

    execute('''
        INSERT INTO "Episode"
        ("episode_name","episode_number_in_project","planned_release_date","id_project",
         "actual_release_date","ready_for_release_flag","ready_for_release_date","id_episode_status")
        VALUES
        (%(episode_name)s,%(episode_number_in_project)s,%(planned_release_date)s,%(id_project)s,
         %(actual_release_date)s,%(ready_for_release_flag)s,%(ready_for_release_date)s,%(id_episode_status)s);
    ''', data)

    flash("Эпизод добавлен.", "ok")
    return redirect(url_for("project.view_project", token=project_token))

@bp.get("/<episode_token>/edit")
def edit_episode_form(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    ep = fetch_one('SELECT * FROM "Episode" WHERE "id_episode"=%(eid)s;', {"eid": id_episode})
    if not ep:
        flash("Эпизод не найден.", "error")
        return redirect(url_for("project.list_projects"))

    project = fetch_one('SELECT "id_project","project_name" FROM "Project" WHERE "id_project"=%(pid)s;', {"pid": ep["id_project"]})
    project_token = make_token("project", ep["id_project"])
    statuses = fetch_all('SELECT "id_episode_status", "episode_status_name" FROM "EpisodeStatus" ORDER BY 1;')
    return render_template("episodes_form.html", mode="edit", project=project, project_token=project_token, statuses=statuses, ep=ep, episode_token=episode_token)

@bp.post("/<episode_token>/edit")
def update_episode(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    # Get project id to redirect back
    cur_ep = fetch_one('SELECT "id_project" FROM "Episode" WHERE "id_episode"=%(eid)s;', {"eid": id_episode})
    if not cur_ep:
        flash("Эпизод не найден.", "error")
        return redirect(url_for("project.list_projects"))
    project_token = make_token("project", cur_ep["id_project"])

    data = {
        "id_episode": id_episode,
        "episode_name": request.form.get("episode_name","").strip(),
        "episode_number_in_project": request.form.get("episode_number_in_project") or None,
        "planned_release_date": request.form.get("planned_release_date") or None,
        "actual_release_date": request.form.get("actual_release_date") or None,
        "ready_for_release_flag": True if request.form.get("ready_for_release_flag") == "on" else False,
        "ready_for_release_date": request.form.get("ready_for_release_date") or None,
        "id_episode_status": request.form.get("id_episode_status") or None,
    }

    if not data["episode_name"]:
        flash("Поле «Название эпизода» обязательно.", "error")
        return redirect(url_for("episode.edit_episode_form", episode_token=episode_token))

    execute('''
        UPDATE "Episode"
        SET "episode_name"=%(episode_name)s,
            "episode_number_in_project"=%(episode_number_in_project)s,
            "planned_release_date"=%(planned_release_date)s,
            "actual_release_date"=%(actual_release_date)s,
            "ready_for_release_flag"=%(ready_for_release_flag)s,
            "ready_for_release_date"=%(ready_for_release_date)s,
            "id_episode_status"=%(id_episode_status)s
        WHERE "id_episode"=%(id_episode)s;
    ''', data)

    flash("Эпизод обновлён.", "ok")
    return redirect(url_for("episode.view_episode", episode_token=episode_token))

@bp.post("/<episode_token>/delete")
def delete_episode(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    ep = fetch_one('SELECT "id_project" FROM "Episode" WHERE "id_episode"=%(eid)s;', {"eid": id_episode})
    if not ep:
        flash("Эпизод не найден.", "error")
        return redirect(url_for("project.list_projects"))
    project_token = make_token("project", ep["id_project"])

    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute('''
                DELETE FROM "StageStatusHistory"
                WHERE "id_stage" IN (
                    SELECT s."id_stage"
                    FROM "Stage" s
                    LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
                    WHERE s."id_episode" = %(eid)s
                       OR f."id_episode" = %(eid)s
                );
            ''', {"eid": id_episode})
            cur.execute('''
                DELETE FROM "StageCheck"
                WHERE "id_stage" IN (
                    SELECT s."id_stage"
                    FROM "Stage" s
                    LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
                    WHERE s."id_episode" = %(eid)s
                       OR f."id_episode" = %(eid)s
                );
            ''', {"eid": id_episode})
            cur.execute('''
                DELETE FROM "DailyProgress"
                WHERE "id_stage" IN (
                    SELECT s."id_stage"
                    FROM "Stage" s
                    LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
                    WHERE s."id_episode" = %(eid)s
                       OR f."id_episode" = %(eid)s
                );
            ''', {"eid": id_episode})
            cur.execute('''
                DELETE FROM "Stage"
                WHERE "id_episode" = %(eid)s
                   OR "id_frame" IN (
                       SELECT f."id_frame" FROM "Frame" f WHERE f."id_episode" = %(eid)s
                   );
            ''', {"eid": id_episode})
            cur.execute('''
                DELETE FROM "PublicationSchedule" WHERE "id_episode" = %(eid)s;
            ''', {"eid": id_episode})
            cur.execute('''
                DELETE FROM "Frame" WHERE "id_episode" = %(eid)s;
            ''', {"eid": id_episode})
            cur.execute('''
                DELETE FROM "Episode" WHERE "id_episode"=%(eid)s;
            ''', {"eid": id_episode})
        flash("Эпизод удалён.", "ok")
    except Exception as err:
        flash(f"Ошибка при удалении эпизода: {err}", "error")
    return redirect(url_for("project.view_project", token=project_token))


@bp.post("/<episode_token>/reschedule")
def reschedule_publication(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("project.list_projects"))

    new_date = request.form.get("new_planned_date") or None
    if not new_date:
        flash("Выберите новую плановую дату.", "error")
        return redirect(url_for("episode.view_episode", episode_token=episode_token))

    try:
        execute('CALL "sp_reschedule_publication"(%(eid)s, %(d)s::date);', {"eid": id_episode, "d": new_date})
        flash("Публикация перенесена (вызвана процедура БД).", "ok")
    except Exception as e:
        flash(f"Ошибка при вызове процедуры: {e}", "error")

    return redirect(url_for("episode.view_episode", episode_token=episode_token))