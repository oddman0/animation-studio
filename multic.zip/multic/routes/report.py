from datetime import date

from flask import Blueprint, render_template, request

from db import get_conn

bp = Blueprint("report", __name__, url_prefix="/reports")


def fetch_all(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchall()


def _get_date_param(name: str, default: date) -> date:
    raw = (request.args.get(name) or "").strip()
    if not raw:
        return default
    try:
        return date.fromisoformat(raw)
    except ValueError:
        return default


def _get_month_param(name: str, default: date) -> date:
    raw = (request.args.get(name) or "").strip()
    if not raw:
        return date(default.year, default.month, 1)
    try:
        year_str, month_str = raw.split("-", 1)
        year = int(year_str)
        month = int(month_str)
        return date(year, month, 1)
    except (ValueError, TypeError):
        return date(default.year, default.month, 1)


def _month_value(value: date) -> str:
    return f"{value.year:04d}-{value.month:02d}"


@bp.get("")
def reports():
    lag_days = int(request.args.get("lag_days", "10") or 10)

    today = date.today()
    date_a = _get_date_param("date_a", today)
    month_v = _get_month_param("month_v", today)
    month_g = _get_month_param("month_g", today)
    month_e = _get_month_param("month_e", today)
    month_z = _get_month_param("month_z", today)

    month_start = month_v
    if month_v.month == 12:
        next_month = date(month_v.year + 1, 1, 1)
    else:
        next_month = date(month_v.year, month_v.month + 1, 1)
    if month_g.month == 12:
        month_g_next = date(month_g.year + 1, 1, 1)
    else:
        month_g_next = date(month_g.year, month_g.month + 1, 1)
    if month_e.month == 12:
        month_e_next = date(month_e.year + 1, 1, 1)
    else:
        month_e_next = date(month_e.year, month_e.month + 1, 1)
    if month_z.month == 12:
        month_z_next = date(month_z.year + 1, 1, 1)
    else:
        month_z_next = date(month_z.year, month_z.month + 1, 1)

    # a) Progress per project (for selected day: sum of per-stage progress / total)
    progress_rows = fetch_all('''
        WITH stage_project AS (
            SELECT
                s."id_stage",
                COALESCE(s."id_project", e."id_project", e2."id_project") AS id_project
            FROM "Stage" s
            LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
            LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
            LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
        ),
        today_dp AS (
            SELECT
                dp."id_stage",
                dp."progress_percent",
                ROW_NUMBER() OVER (PARTITION BY dp."id_stage" ORDER BY dp."progress_date" DESC, dp."id_progress" DESC) AS rn
            FROM "DailyProgress" dp
            JOIN stage_project sp ON sp."id_stage" = dp."id_stage"
            WHERE dp."progress_date" = %(as_of)s
        ),
        totals AS (
            SELECT
                sp.id_project,
                COUNT(*) AS total_stages,
                COALESCE(SUM(COALESCE(t.progress_percent, 0)), 0) AS today_sum
            FROM stage_project sp
            LEFT JOIN today_dp t ON t."id_stage" = sp."id_stage" AND t.rn = 1
            GROUP BY sp.id_project
        )
        SELECT
            p."id_project",
            p."project_name",
            CASE
              WHEN COALESCE(t.total_stages, 0) = 0 THEN 0
              ELSE ROUND((t.today_sum::numeric / t.total_stages::numeric), 2)
            END AS overall_percent
        FROM "Project" p
        LEFT JOIN totals t ON t.id_project = p."id_project"
        ORDER BY p."project_name";
    ''', {"as_of": date_a})

    # b) Projects lagging more than N days
    lag_rows = fetch_all('''
        SELECT
            p."project_name",
            p."planned_end_date",
            p."actual_end_date",
            (COALESCE(p."actual_end_date", CURRENT_DATE) - p."planned_end_date")::int AS delay_days
        FROM "Project" p
        WHERE p."planned_end_date" IS NOT NULL
          AND (COALESCE(p."actual_end_date", CURRENT_DATE) - p."planned_end_date") > %(lag_days)s
        ORDER BY delay_days DESC;
    ''', {"lag_days": lag_days})

    # c) Frames completed by each artist in current month
    frames_by_artist = fetch_all('''
        SELECT
            e."surname" || ' ' || e."name" AS artist,
            COUNT(DISTINCT s."id_frame") AS frames_done
        FROM "Stage" s
        JOIN "Employees" e ON e."id_employee" = s."id_responsible_employee"
        WHERE s."id_frame" IS NOT NULL
          AND s."actual_end_datetime" >= %(start)s
          AND s."actual_end_datetime" < %(end)s
        GROUP BY artist
        ORDER BY frames_done DESC, artist;
    ''', {"start": month_start, "end": next_month})

    # d) Avg time for stage "композитинг" per project (selected month)
    avg_paint_time = fetch_all('''
        WITH stage_project AS (
            SELECT
                s."id_stage",
                s."stage_type_id",
                s."start_datetime",
                s."actual_end_datetime",
                COALESCE(s."id_project", e."id_project", e2."id_project") AS id_project
            FROM "Stage" s
            LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
            LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
            LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
        )
        SELECT
            p."project_name",
            AVG(
                CASE
                  WHEN st."stage_type_id" IS NOT NULL
                  THEN EXTRACT(EPOCH FROM (sp."actual_end_datetime" - sp."start_datetime")) / 3600.0
                  ELSE NULL
                END
            ) AS avg_hours
        FROM "Project" p
        LEFT JOIN stage_project sp ON sp.id_project = p."id_project"
          AND sp."start_datetime" IS NOT NULL
          AND sp."actual_end_datetime" IS NOT NULL
          AND sp."actual_end_datetime" >= %(start)s
          AND sp."actual_end_datetime" < %(end)s
        LEFT JOIN "StageType" st ON st."stage_type_id" = sp."stage_type_id"
          AND st."stage_type_name" ILIKE '%%композит%%'
        GROUP BY p."project_name"
        ORDER BY p."project_name";
    ''', {"start": month_g, "end": month_g_next})

    # e) Episodes waiting QC on compositing
    qc_rows = fetch_all('''
        WITH stage_ctx AS (
            SELECT
                s."id_stage",
                s."id_episode",
                s."id_frame"
            FROM "Stage" s
        ),
        ep_ctx AS (
            SELECT
                sc."id_stage",
                COALESCE(sc."id_episode", f."id_episode") AS id_episode
            FROM stage_ctx sc
            LEFT JOIN "Frame" f ON f."id_frame" = sc."id_frame"
        )
        SELECT DISTINCT
            p."project_name",
            e."episode_name",
            f."frame_number_in_episode",
            ss."stage_status_name"
        FROM "Stage" s
        JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
        JOIN ep_ctx ec ON ec."id_stage" = s."id_stage"
        JOIN "Episode" e ON e."id_episode" = ec.id_episode
        JOIN "Project" p ON p."id_project" = e."id_project"
        LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
        LEFT JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        WHERE st."stage_type_name" ILIKE '%%композит%%'
          AND ss."stage_status_name" ILIKE '%%провер%%'
          AND (s."start_datetime" IS NULL OR s."start_datetime" < %(end)s)
        ORDER BY p."project_name", e."episode_name", f."frame_number_in_episode";
    ''', {"end": month_e_next})

    # f) Workload distribution
    load_rows = fetch_all('''
        SELECT
            e."surname" || ' ' || e."name" AS artist,
            COUNT(DISTINCT s."id_stage") AS active_stages
        FROM "Stage" s
        JOIN "Employees" e ON e."id_employee" = s."id_responsible_employee"
        JOIN "StageStatus" ss ON ss."id_stage_status" = s."id_stage_status"
        WHERE ss."stage_status_name" NOT IN ('Принят','Завершён')
        GROUP BY artist
        ORDER BY active_stages DESC, artist;
    ''')

    # g) Forecast finish date (simple pace estimate)
    forecast_rows = fetch_all('''
        WITH stage_project AS (
            SELECT
                s."id_stage",
                COALESCE(s."id_project", e."id_project", e2."id_project") AS id_project
            FROM "Stage" s
            LEFT JOIN "Episode" e ON e."id_episode" = s."id_episode"
            LEFT JOIN "Frame" f ON f."id_frame" = s."id_frame"
            LEFT JOIN "Episode" e2 ON e2."id_episode" = f."id_episode"
        ),
        last_progress AS (
            SELECT
                sp.id_project,
                dp."id_stage",
                dp."progress_percent",
                ROW_NUMBER() OVER (PARTITION BY dp."id_stage" ORDER BY dp."progress_date" DESC, dp."id_progress" DESC) AS rn
            FROM "DailyProgress" dp
            JOIN stage_project sp ON sp."id_stage" = dp."id_stage"
        ),
        overall AS (
            SELECT
                p."id_project",
                COALESCE(AVG(lp."progress_percent") FILTER (WHERE lp.rn = 1), 0) AS overall_percent
            FROM "Project" p
            LEFT JOIN last_progress lp ON lp.id_project = p."id_project"
            GROUP BY p."id_project"
        ),
        rate AS (
            SELECT
                sp.id_project,
                AVG(delta) / 7.0 AS daily_rate
            FROM (
                SELECT
                    sp.id_project,
                    dp."id_stage",
                    (MAX(dp."progress_percent") - MIN(dp."progress_percent")) AS delta
                FROM "DailyProgress" dp
                JOIN stage_project sp ON sp."id_stage" = dp."id_stage"
                WHERE dp."progress_date" >= CURRENT_DATE - INTERVAL '7 days'
                GROUP BY sp.id_project, dp."id_stage"
            ) t
            JOIN stage_project sp ON sp.id_project = t.id_project
            GROUP BY sp.id_project
        )
        SELECT
            p."project_name",
            o.overall_percent,
            r.daily_rate,
            CASE
              WHEN r.daily_rate > 0
              THEN (CURRENT_DATE + CEIL((100 - o.overall_percent) / r.daily_rate) * INTERVAL '1 day')::date
              ELSE NULL
            END AS прогноз
        FROM "Project" p
        LEFT JOIN overall o ON o."id_project" = p."id_project"
        LEFT JOIN rate r ON r.id_project = p."id_project"
        ORDER BY p."project_name";
    ''')

    # h) Defects and reworks by stage type
    defect_rows = fetch_all('''
        SELECT
            st."stage_type_name",
            COUNT(*) FILTER (WHERE cr."check_result_name" ILIKE '%%брак%%') AS defects,
            COUNT(*) FILTER (WHERE cr."check_result_name" ILIKE '%%доработ%%') AS reworks,
            COUNT(*) FILTER (WHERE cr."check_result_name" ILIKE '%%не принят%%') AS rejected
        FROM "StageCheck" sc
        JOIN "Stage" s ON s."id_stage" = sc."id_stage"
        JOIN "StageType" st ON st."stage_type_id" = s."stage_type_id"
        JOIN "CheckResult" cr ON cr."id_check_result" = sc."id_check_result"
        WHERE sc."check_datetime" >= %(start)s
          AND sc."check_datetime" < %(end)s
        GROUP BY st."stage_type_name"
        ORDER BY st."stage_type_name";
    ''', {"start": month_z, "end": month_z_next})

    return render_template(
        "reports.html",
        lag_days=lag_days,
        month_start=month_start,
        date_a=date_a,
        month_v_value=_month_value(month_v),
        month_g_value=_month_value(month_g),
        month_e_value=_month_value(month_e),
        month_z_value=_month_value(month_z),
        progress_rows=progress_rows,
        lag_rows=lag_rows,
        frames_by_artist=frames_by_artist,
        avg_paint_time=avg_paint_time,
        qc_rows=qc_rows,
        load_rows=load_rows,
        forecast_rows=forecast_rows,
        defect_rows=defect_rows,
    )
