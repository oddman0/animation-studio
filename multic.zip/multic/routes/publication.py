from flask import Blueprint, render_template, request, redirect, url_for, flash

from db import get_conn
from tokens import make_token, parse_token

bp = Blueprint("publication", __name__, url_prefix="/publications")


def fetch_all(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchall()


def fetch_one(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})
        return cur.fetchone()


def execute(sql, params=None):
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(sql, params or {})


def _attach_tokens(row):
    row["token"] = make_token("publication", row["id_publication_schedule"])
    row["episode_token"] = make_token("episode", row["id_episode"])
    return row


@bp.get("")
def list_publications():
    q = request.args.get("q", "").strip()
    where_clause = ""
    params = {}
    if q:
        where_clause = 'WHERE p."project_name" ILIKE %(q)s'
        params["q"] = f"%{q}%"

    rows = fetch_all(f'''
        SELECT DISTINCT ON (ps."id_episode")
            ps."id_publication_schedule",
            ps."id_episode",
            p."project_name",
            e."episode_name",
            pst."publication_status_name",
            ps."planned_publication_date",
            ps."actual_publication_date"
        FROM "PublicationSchedule" ps
        JOIN "Episode" e ON e."id_episode" = ps."id_episode"
        JOIN "Project" p ON p."id_project" = e."id_project"
        LEFT JOIN "PublicationStatus" pst ON pst."id_publication_status" = ps."id_publication_status"
        {where_clause}
        ORDER BY ps."id_episode", ps."id_publication_schedule" DESC;
    ''', params)

    rows = [_attach_tokens(r) for r in rows]
    return render_template("publications_list.html", rows=rows, q=q)


@bp.get("/history/<episode_token>")
def publication_history(episode_token: str):
    try:
        id_episode = parse_token(episode_token, "episode")
    except ValueError:
        flash("Неверная ссылка на эпизод.", "error")
        return redirect(url_for("publication.list_publications"))

    ep = fetch_one('''
        SELECT e."episode_name", p."project_name"
        FROM "Episode" e
        JOIN "Project" p ON p."id_project" = e."id_project"
        WHERE e."id_episode" = %(eid)s;
    ''', {"eid": id_episode})
    if not ep:
        flash("Эпизод не найден.", "error")
        return redirect(url_for("publication.list_publications"))

    rows = fetch_all('''
        SELECT
            ps."id_publication_schedule",
            pst."publication_status_name",
            ps."planned_publication_date",
            ps."actual_publication_date"
        FROM "PublicationSchedule" ps
        LEFT JOIN "PublicationStatus" pst ON pst."id_publication_status" = ps."id_publication_status"
        WHERE ps."id_episode" = %(eid)s
        ORDER BY ps."id_publication_schedule" DESC;
    ''', {"eid": id_episode})

    return render_template(
        "publications_history.html",
        ep=ep,
        episode_token=episode_token,
        rows=rows,
    )


@bp.get("/new")
def new_publication_form():
    episodes = fetch_all('''
        SELECT
            e."id_episode",
            e."episode_name",
            e."episode_number_in_project",
            p."project_name"
        FROM "Episode" e
        JOIN "Project" p ON p."id_project" = e."id_project"
        ORDER BY p."project_name", e."episode_number_in_project", e."episode_name";
    ''')
    statuses = fetch_all('SELECT "id_publication_status","publication_status_name" FROM "PublicationStatus" ORDER BY 1;')
    return render_template("publications_form.html", mode="new", item=None, token=None, episodes=episodes, statuses=statuses)


@bp.post("/new")
def create_publication():
    data = {
        "id_episode": request.form.get("id_episode") or None,
        "id_publication_status": request.form.get("id_publication_status") or None,
        "planned_publication_date": request.form.get("planned_publication_date") or None,
        "actual_publication_date": request.form.get("actual_publication_date") or None,
    }

    if not data["id_episode"]:
        flash("Выберите эпизод.", "error")
        return redirect(url_for("publication.new_publication_form"))

    execute('''
        INSERT INTO "PublicationSchedule"
        ("id_episode","id_publication_status","planned_publication_date","actual_publication_date")
        VALUES
        (%(id_episode)s,%(id_publication_status)s,%(planned_publication_date)s,%(actual_publication_date)s);
    ''', data)

    flash("Запись публикации добавлена.", "ok")
    return redirect(url_for("publication.list_publications"))


@bp.get("/<token>/edit")
def edit_publication_form(token: str):
    try:
        id_publication_schedule = parse_token(token, "publication")
    except ValueError:
        flash("Неверная ссылка на публикацию.", "error")
        return redirect(url_for("publication.list_publications"))

    item = fetch_one('SELECT * FROM "PublicationSchedule" WHERE "id_publication_schedule" = %(pid)s;', {"pid": id_publication_schedule})
    if not item:
        flash("Запись публикации не найдена.", "error")
        return redirect(url_for("publication.list_publications"))

    episodes = fetch_all('''
        SELECT
            e."id_episode",
            e."episode_name",
            e."episode_number_in_project",
            p."project_name"
        FROM "Episode" e
        JOIN "Project" p ON p."id_project" = e."id_project"
        ORDER BY p."project_name", e."episode_number_in_project", e."episode_name";
    ''')
    statuses = fetch_all('SELECT "id_publication_status","publication_status_name" FROM "PublicationStatus" ORDER BY 1;')
    return render_template("publications_form.html", mode="edit", item=item, token=token, episodes=episodes, statuses=statuses)


@bp.post("/<token>/edit")
def update_publication(token: str):
    try:
        id_publication_schedule = parse_token(token, "publication")
    except ValueError:
        flash("Неверная ссылка на публикацию.", "error")
        return redirect(url_for("publication.list_publications"))

    data = {
        "id_publication_schedule": id_publication_schedule,
        "id_episode": request.form.get("id_episode") or None,
        "id_publication_status": request.form.get("id_publication_status") or None,
        "planned_publication_date": request.form.get("planned_publication_date") or None,
        "actual_publication_date": request.form.get("actual_publication_date") or None,
    }

    if not data["id_episode"]:
        flash("Выберите эпизод.", "error")
        return redirect(url_for("publication.edit_publication_form", token=token))

    execute('''
        UPDATE "PublicationSchedule"
        SET "id_episode"=%(id_episode)s,
            "id_publication_status"=%(id_publication_status)s,
            "planned_publication_date"=%(planned_publication_date)s,
            "actual_publication_date"=%(actual_publication_date)s
        WHERE "id_publication_schedule"=%(id_publication_schedule)s;
    ''', data)

    flash("Запись публикации обновлена.", "ok")
    return redirect(url_for("publication.list_publications"))


@bp.post("/<token>/delete")
def delete_publication(token: str):
    try:
        id_publication_schedule = parse_token(token, "publication")
    except ValueError:
        flash("Неверная ссылка на публикацию.", "error")
        return redirect(url_for("publication.list_publications"))

    execute('DELETE FROM "PublicationSchedule" WHERE "id_publication_schedule"=%(pid)s;', {"pid": id_publication_schedule})
    flash("Запись публикации удалена.", "ok")
    return redirect(url_for("publication.list_publications"))
