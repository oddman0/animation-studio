# Minion Project Web (Flask + PostgreSQL, no ORM)

Веб-интерфейс для таблицы **Project** (просмотр / добавление / редактирование / удаление), без ORM — только SQL.

## 1) Установка
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Mac:
# source .venv/bin/activate

pip install -r requirements.txt
```

## 2) Настройка подключения к БД
Скопируй файл `.env.example` в `.env` и проверь параметры:
- host: localhost
- port: 5432
- db: pbd
- user: postgres
- password: 1523

## 3) Запуск
```bash
python app.py
```

Открой в браузере:
- http://127.0.0.1:5000/projects

## Примечание
Если таблица `Project` в твоей БД называется иначе (например `"Project"` с кавычками), в файле `routes/project.py`
уже используется `"Project"` и кавычки — это подходит под твой стиль DDL.


IDs в интерфейсе скрыты: ссылки формируются через подписанные токены (itsdangerous) — пользователь не видит внутренние id.
