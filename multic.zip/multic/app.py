from flask import Flask, redirect, url_for
import os

def create_app():
    app = Flask(__name__)
    app.secret_key = os.getenv("SECRET_KEY", "dev-secret")

    from routes.main import bp as main_bp
    from routes.project import bp as project_bp
    from routes.episode import bp as episode_bp
    from routes.frame import bp as frame_bp
    from routes.employee import bp as employee_bp
    from routes.publication import bp as publication_bp
    from routes.report import bp as report_bp

    app.register_blueprint(main_bp)
    app.register_blueprint(project_bp)
    app.register_blueprint(episode_bp)
    app.register_blueprint(frame_bp)
    app.register_blueprint(employee_bp)
    app.register_blueprint(publication_bp)
    app.register_blueprint(report_bp)

    @app.get("/health")
    def health():
        from db import get_conn
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT 1 AS ok;")
            row = cur.fetchone()
        return {"db": "ok", "result": row}

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
